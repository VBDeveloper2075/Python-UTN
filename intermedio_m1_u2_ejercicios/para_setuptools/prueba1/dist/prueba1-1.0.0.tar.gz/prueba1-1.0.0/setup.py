from setuptools import setup, find_packages

from distutils.core import setup 
setup( 
name = 'prueba1', 
version = '1.0.0', 
py_modules = ['prueba1'], 
author = 'hfpython', 
author_email = 'juanbarretor@gmail.com', 
url = 'fascinaweb.com', 
description = 'Es una prueba de uso', 
packages=find_packages(),
)

 

